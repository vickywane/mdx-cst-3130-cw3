import axios from "axios";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { PutCommand, DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";

let awsConfig = {
    region: "us-east-1",
    endpoint: "https://dynamodb.us-east-1.amazonaws.com"
};

// Create new DocumentClient
const client = new DynamoDBClient({ region: awsConfig.region });
export const documentClient = DynamoDBDocumentClient.from(client);
const SENTIMENT_PROCESSOR_ENDPOINT= "https://kmqvzxr68e.execute-api.us-east-1.amazonaws.com/prod"
const TABLE_NAME = "mdx-fx-sentiments"

export const handler = async (event) => {
    for (let record of event.Records) {
        if (record.eventName === "INSERT") {
            const currency = record.dynamodb.NewImage.CurrencySymbol.S;
            const summary = record.dynamodb.NewImage.Summary.S;  
            const timeStamp = record.dynamodb.NewImage.TimePublished.N;
            
            try {
                let response = await axios.post(
                    SENTIMENT_PROCESSOR_ENDPOINT,
                    {
                        text: summary
                    },
                );
              let sentiment = await response.data.sentiment
              const command = new PutCommand({
                TableName: TABLE_NAME,
                Item: {
                    "CurrencySymbol": currency,
                    "TimePublished": Number(timeStamp),
                    "Sentiment": sentiment
                }
            });

                await documentClient.send(command);
                   
            } catch (error) {
                console.error(error);
            }
        }
    }
};